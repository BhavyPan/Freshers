# OBSIDIAN '26 — Smart QR Entry & Access Management System

Project: Digital entry system for OBSIDIAN '26 Freshers 2K26. Verifies registered junior IDs
(uploaded via Excel/CSV), records check-ins in real time, generates the event QR code, and
delivers an immersive 3D obsidian-themed entry experience.

Source spec: /home/z/my-project/upload/OBSIDIAN26_Smart_QR_Entry_Access_Management_System_UPDATED.pdf

## Tech Stack
- Next.js 16 App Router, TypeScript, Tailwind CSS 4, shadcn/ui (New York), lucide-react, framer-motion
- Prisma + SQLite (db/custom.db) — replaces spec's Supabase (environment constraint)
- 3D: three + @react-three/fiber + @react-three/drei (lazy loaded, low-end fallback)
- Sheets: xlsx (SheetJS) · QR: qrcode · PDF: pdf-lib · Hashing: bcryptjs
- Single user-visible route: `/` (src/app/page.tsx) — hash-based SPA routing (#/verify, #/admin/*)
- Backend: Next.js API routes only (no server actions)
- Live dashboard updates: TanStack Query polling (4s)

## Architecture (hash routes on `/`)
- `` or `#/` → 3D OBSIDIAN landing (crystal, particles, contours)
- `#/verify` → Student ID verification (scanning animation)
- `#/result` → Access result (GRANTED / ALREADY CHECKED_IN / DENIED)
- `#/admin`, `#/admin/dashboard|registry|qr|reports` → auth-gated organizer area

## Prisma Models (prisma/schema.prisma — pushed)
- Student { studentId unique, name, mobile?, department?, email?, year?, extraData?, checkedIn, checkinAt?, checkinBy? }
- AdminUser { username unique, passwordHash, role ADMIN|VOLUNTEER, displayName? }
- AdminSession { token unique, userId, expiresAt }
- AuditLog { rawInput, lookupId, result GRANTED|ALREADY_CHECKED_IN|DENIED|RATE_LIMITED, studentId?, studentKey?, ipHash?, userAgent? }
- EventSettings { eventToken unique, eventName, tagline }

## API Contract (source of truth: src/lib/types.ts)
Public:
- POST /api/verify {studentId, token?} → VerifyResponse (rate limit 12/min/IP, 429 → result RATE_LIMITED; bad format → 400 result INVALID)
- GET /api/health

Admin auth (cookie `obsidian_session`, httpOnly, 12h):
- POST /api/admin/login {username,password} → LoginResponse
- POST /api/admin/logout → {ok}
- GET /api/admin/me → LoginResponse (user or 401)
- POST /api/admin/password {currentPassword,newPassword} → {ok}

Admin data (VOLUNTEER: dashboard/registry/check-in allowed; ADMIN only: import, export, QR manage, audit, uncheckin/edit/delete):
- GET /api/admin/stats → StatsResponse (KPIs, dept breakdown, 15-min timeline last 6h, recent 12 check-ins)
- GET /api/admin/students?q&status=ALL|CHECKED_IN|NOT_ARRIVED&dept&page&pageSize&sort → StudentsResponse (attempts count included)
- PATCH /api/admin/students/[id] {action: checkin|uncheckin|edit, name?,...,reason?} → {ok, student}
- DELETE /api/admin/students/[id] → {ok}
- POST /api/admin/import/preview (multipart file) → ImportPreviewResponse
- POST /api/admin/import/commit (multipart file + mapping JSON + mode MERGE|REPLACE) → ImportCommitResponse
- GET /api/admin/audit?q&result&page&pageSize&studentKey → AuditResponse
- GET /api/admin/export?scope=checkedin|notarrived|full&format=csv|xlsx|pdf → file download
- GET /api/qr → QrResponse (admin session required; includes qrDataUrl PNG)
- POST /api/qr/regenerate → QrResponse (rotates eventToken)
- GET /api/qr/download?format=png|svg|pdf → file download (admin session required)

QR target URL: `{proto}://{host}/?t={eventToken}` (token is a soft check — invalid token still verifies but is flagged in audit).

## Seeded demo data (src/lib/seed.ts, ensureSeeded())
- admin / obsidian26 (ADMIN) · volunteer / volunteer26 (VOLUNTEER)
- ~80 demo students (OBS26-001…) across CSE/ECE/EEE/ME/CE/IT/AIML, ~14 already checked in, plus some DENIED audit entries

---
Task ID: 1
Agent: main (Z.ai Code)
Task: Project analysis, dependency install, Prisma schema, types contract, worklog setup

Work Log:
- Extracted full requirements from uploaded PDF (8 pages spec, 2 pages PDF)
- Installed: three, @react-three/fiber, @react-three/drei, xlsx, qrcode, bcryptjs, pdf-lib (+ @types)
- Rewrote prisma/schema.prisma (Student, AdminUser, AdminSession, AuditLog, EventSettings), ran `bun run db:push` OK
- Created src/lib/types.ts — the exact API contract shared by backend agent & frontend
- Created this worklog

Stage Summary:
- Scaffold ready; DB pushed; contract frozen. Backend delegated to full-stack agent (Task 2-b), frontend built by main agent (Task 2-a).

---
Task ID: 2-b
Agent: full-stack-developer (subagent)
Task: Implement ALL backend API routes + libs + seed exactly per the API contract in src/lib/types.ts and this worklog. No page.tsx changes, no new pages, no other routes.

Work Log:
- Removed `log: ['query']` from src/lib/db.ts (only permitted change) so Prisma queries never hit the console
- Fixed src/lib/types.ts line 1: the file self-imported `AdminRole` from "./types" but never defined it; replaced that import with `export type AdminRole = "ADMIN" | "VOLUNTEER"` (additive fix — no existing exported shape changed)
- Created src/lib/normalize.ts (normalizeStudentId / isValidStudentId / sanitizeCell — control-char stripping done via charCode loop, no regex control literals)
- Created src/lib/rate-limit.ts (in-memory sliding window, 12 req/min/IP, 5000-key cap with pruning; getClientIp reads x-forwarded-for / x-real-ip)
- Created src/lib/audit.ts (logAudit — sha256(ip) → 16-char ipHash, UA truncated 180, never throws)
- Created src/lib/auth.ts (bcryptjs 10 rounds, randomBytes(32) session tokens, 12h expiry, cookie `obsidian_session` httpOnly/lax/path=/maxAge 43200, requireAdmin role guard, clearSession)
- Created src/lib/seed.ts + prisma/seed.ts; ran `bun run prisma/seed.ts` → 80 students (OBS26-001…080, 7 rotating depts, realistic Indian names), 14 checked-in over last 40 min, 2 admin users, 22 audit logs (14 GRANTED matching the seeded check-ins so the dashboard timeline shows activity + 6 DENIED + 2 ALREADY_CHECKED_IN); ensureSeeded() is promise-cached + idempotent + concurrency-safe
- Created src/lib/sheet.ts (shared XLSX/CSV reader: 8 MB cap, .xlsx/.xls/.csv name check, header:1 raw:false parsing, sanitizeCell per cell, autoMapHeaders regexes, isValidMapping)
- Created src/lib/qr.ts (getBaseUrl via x-forwarded-host/host + x-forwarded-proto, getEventSettings, buildEventUrl, qrDataUrl/qrPngBuffer/qrSvgString with dark #1a0b2e ECC-H, qrPosterPdf A4 portrait poster via pdf-lib)
- Created src/lib/export.ts (buildCsv with # header comments, buildXlsx via aoa_to_sheet, buildAttendancePdf A4 landscape table — 6 columns summing 740pt ≤ 770, 8.5pt rows, purple header fill, alternating lavender rows, colored status, 34 rows/page with repeated header + footer, width-aware ellipsis truncation)
- Created all API routes: health (+ replaced root /api route), verify (format → rate-limit → lookup, race-safe updateMany check-in, soft token check, 400/429/DENIED-200/GRANTED/ALREADY), admin login/logout/me/password (300ms fail delay, other-session invalidation), stats (KPIs, dept groupBy merge, 15-min buckets over 6h continuous, recent 12), students (q/status/dept/page/pageSize/sort, per-row attempt counts via auditLog groupBy), students/[id] PATCH checkin|uncheckin|edit + DELETE (role gates: uncheckin/edit/delete ADMIN-only, checkin any role, race-safe, UCHECKED/EDITED/DELETED audited), import/preview + import/commit (multipart, automap, validation counts, MERGE upsert never touching checkedIn, REPLACE deleteMany, chunked inArray lookups), audit (q/result/studentKey filters, comma-list result support), export (csv+xlsx+pdf, BOM for Excel, attachment disposition, obsidian26-{scope}-{stamp} filenames), qr GET, qr/regenerate POST (ADMIN, token rotation), qr/download GET (png/svg/pdf)
- Smoke-tested every endpoint against the running dev server (all flows + 400/401/403/404/429 paths + role restrictions + import MERGE/REPLACE + file-type/mapping validation + all 3 export formats + all 3 QR download formats), then reset the DB and re-ran the seed for a pristine demo state
- `bun run lint` → exit 0, no errors or warnings

Stage Summary:
- Files created: src/lib/{normalize,rate-limit,audit,auth,seed,qr,export,sheet}.ts, prisma/seed.ts, src/app/api/{route.ts,health/route.ts,verify/route.ts}, src/app/api/admin/{login,logout,me,password,stats,students,students/[id],import/preview,import/commit,audit,export}/route.ts, src/app/api/qr/{route.ts,regenerate/route.ts,download/route.ts}
- Modified: src/lib/db.ts (query logging removed), src/lib/types.ts (added missing `export type AdminRole` — see Work Log), src/app/api/route.ts (now a health check), worklog.md
- Seed status: `bun run prisma/seed.ts` run successfully — 80 students / 14 checked in / 2 admins / 22 audit logs; re-ran after smoke tests so live DB is pristine
- Lint status: `bun run lint` passes clean (exit 0)
- Contract deviations: NONE on any response shape (VerifyResponse, StatsResponse, StudentsResponse, ImportPreviewResponse, ImportCommitResponse, AuditResponse, QrResponse, LoginResponse all match src/lib/types.ts exactly; verified live). Two notes: (1) src/lib/types.ts referenced `AdminRole` without defining it (broken self-import) — added the type definition, no existing shape changed; (2) SQLite/Prisma does not support `mode: 'insensitive'` (validated at runtime), so `contains` filters rely on SQLite LIKE's built-in ASCII case-insensitivity — live-tested, lowercase searches match uppercase data. Seed inserts 14 GRANTED audit logs matching the seeded check-ins (spec listed DENIED + ALREADY only) so the dashboard 6h timeline reflects the 14 seeded check-ins.

---
Task ID: 2-a
Agent: main (Z.ai Code)
Task: Build entire frontend SPA on `/` — 3D landing, verify flow, result, admin (login, dashboard, registry+import, QR, reports+audit), obsidian theme.

Work Log:
- Rewrote src/app/globals.css — OBSIDIAN dark palette in :root/.dark (no indigo/blue; purple + crimson only), custom design system (obs-card, obs-gradient-text, obs-text-glow, grain, contour drift animations, scan sweep, live pulse, shimmer, spark rise, custom scrollbars, grid dots, divider diamond, reduced-motion guard)
- src/app/layout.tsx — fonts Unbounded (display) + Space Grotesk (body) via next/font, metadata, dark html, themeColor; public/obsidian-icon.svg favicon
- src/lib/use-hash-route.ts — typed hash router (public landing/verify/result + admin sections)
- src/lib/api-client.ts — typed fetch client for every endpoint + export/QR download URL helpers
- src/lib/client-store.ts — zustand store (verify result, admin session, event token from ?t= → sessionStorage)
- src/app/page.tsx renders <ObsidianApp/> (single user-visible route, hash SPA)
- Components (src/components/obsidian/): ContourBackground (topographic SVG layers + rising sparks + grain + vignette), ObsidianLogo/Glyph, CrystalFallback (animated SVG crystal), use-3d-support (WebGL/reduced-motion/deviceMemory detection), CrystalScene (R3F: faceted icosahedron + emissive core + wireframe shell + twin halo rings + orbiting shards + additive glow sprite + Sparkles, pointer parallax), Landing (staggered entrance, FRESHERS 2K26 chip, OBSIDIAN gradient headline, divider, UNFOLD THE UNKNOWN, Begin Entry CTA, bottom bar w/ organizer login), VerifyView (step tracker, big mono ID input, client validation, ~1.35s themed ScanningOverlay w/ cycling steps + sweep + hex rings), ResultView (GRANTED purple glow + SparkleBurst + student card + time; ALREADY amber; DENIED crimson + registration-desk guidance; rate-limit/invalid states; forwarded-QR warning), AdminLogin (shake on error, demo creds details), AdminShell (desktop sidebar + mobile Sheet nav, live clock, LIVE badge, role gating, sticky footer), DashboardView (4 KPI cards, fill-rate progress, recharts AreaChart 6h timeline + grouped BarChart dept split, live recent check-ins list w/ AnimatePresence, 4s polling), RegistryView (debounced search, status/dept/sort Selects, paginated table w/ status badges, manual check-in (any role), revert/edit/delete (ADMIN), edit dialog, delete confirm), ImportWizard (dropzone, server preview, auto-mapped column Selects, validation chips, sample table, MERGE/REPLACE mode cards, commit + success summary), QRView (bracketed QR preview, URL + copy, masked token reveal, PNG/SVG/PDF downloads, rotate-token AlertDialog, setup checklist), ReportsView (3 export cards w/ live counts + 9 export links, audit trail table w/ result filters + search + pagination), SparkleBurst, ScanningOverlay
- Fixed lint: extracted NavList/UserChip from AdminShell (react-hooks/static-components), setTimeout-wrapped clocks (set-state-in-effect), removed stale eslint-disable, aria-labels on all icon-only table buttons
- Full agent-browser QA (see verification below); VLM screenshot audits of landing/result/dashboard/QR/reports/mobile

Stage Summary:
- VERIFIED WORKING (agent-browser, all passed):
  - Landing: 3D crystal renders (icosahedron + rings + shards + particles), all text/CTA present
  - Verify flow: scanning animation → OBS26-050 → ACCESS GRANTED (Shaurya Bose, CSE, time) ✓; OBS26-001 → ALREADY CHECKED IN ✓; invalid ID → ACCESS DENIED ✓
  - Rate limit: 12 req/min then 429 themed message ✓
  - Token: ?t=faketoken captured to sessionStorage, result shows "forwarded/outdated QR" warning ✓
  - Admin: login admin/obsidian26 ✓ volunteer/volunteer26 ✓; logout ✓; session restore on refresh ✓
  - Dashboard: KPIs 80/15/65/7 live (4s polling confirmed in dev.log), area + bar charts render, recent check-ins with timestamps ✓
  - Registry: debounced search (ananya/OBS26-061), status/dept filters, manual check-in (Ananya → IN 9:44 AM), revert/edit/delete buttons (ADMIN), pagination ✓
  - Import: CSV upload → preview 4 valid/1 missing ID/1 duplicate, auto-map (Register No/Full Name/Branch/Mobile/Email/Study Year), MERGE commit → 84 total ✓
  - QR: preview + URL + masked token; downloads PNG (1024px, 9KB) / SVG / PDF poster (38KB) all HTTP 200 valid files; token rotation 5296→d82c ✓
  - Reports: 3 scope cards × CSV (BOM)/XLSX (valid Excel 2007+)/PDF all 200; audit table w/ GRANTED/DENIED/ALREADY rows + filters ✓
  - Volunteer: no Reports nav, no Import tab ✓
  - Mobile 390px: landing (bottom bar visible), verify form, dashboard 2×2 KPI grid, Sheet nav drawer ✓
  - Sticky footers: admin mt-auto footer, landing bottom bar ✓
  - bun run lint: 0 errors · dev.log: no runtime errors (only benign THREE context-lost on canvas unmount)
- Known minor: THREE.Clock deprecation warning in console (three.js r180, harmless); Registry search requires exact-ish matching (SQLite LIKE contains)

