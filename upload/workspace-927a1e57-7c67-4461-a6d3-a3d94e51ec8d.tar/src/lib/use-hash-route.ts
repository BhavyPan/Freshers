"use client";

import { useCallback, useEffect, useState } from "react";

export type AppRoute =
  | { area: "public"; step: "landing" | "verify" | "result" }
  | { area: "admin"; section: "login" | "dashboard" | "registry" | "qr" | "reports" };

function parseHash(hash: string): AppRoute {
  const clean = hash.replace(/^#\/?/, "").split("?")[0].replace(/\/$/, "");
  if (clean === "admin" || clean.startsWith("admin/")) {
    const sub = clean.replace("admin", "").replace("/", "");
    switch (sub) {
      case "dashboard":
        return { area: "admin", section: "dashboard" };
      case "registry":
        return { area: "admin", section: "registry" };
      case "qr":
        return { area: "admin", section: "qr" };
      case "reports":
        return { area: "admin", section: "reports" };
      default:
        return { area: "admin", section: "login" };
    }
  }
  if (clean === "verify") return { area: "public", step: "verify" };
  if (clean === "result") return { area: "public", step: "result" };
  return { area: "public", step: "landing" };
}

export function useHashRoute() {
  const [route, setRoute] = useState<AppRoute>(() =>
    parseHash(typeof window === "undefined" ? "" : window.location.hash)
  );

  useEffect(() => {
    const onChange = () => setRoute(parseHash(window.location.hash));
    window.addEventListener("hashchange", onChange);
    return () => window.removeEventListener("hashchange", onChange);
  }, []);

  const navigate = useCallback((to: string) => {
    if (window.location.hash === to) {
      setRoute(parseHash(to));
    } else {
      window.location.hash = to;
    }
  }, []);

  return { route, navigate };
}

export function routeToHash(route: AppRoute): string {
  if (route.area === "admin") {
    return route.section === "login" ? "#/admin" : `#/admin/${route.section}`;
  }
  if (route.step === "landing") return "#/";
  return `#/${route.step}`;
}
